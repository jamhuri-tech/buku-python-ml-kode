# Praktikum Bab 3–17 · Revisi keterbacaan

Paket mahasiswa berisi 15 notebook. Bab 3 memakai versi v3; Bab 4–17 versi v2.

## Cara mengerjakan

1. Ekstrak ZIP ini, lalu impor satu file `.ipynb` ke Kaggle.
2. Jalankan sel berurutan dari atas ke bawah. Data latihan sudah disediakan.
3. Sel persiapan dan fungsi pemeriksa cukup dijalankan.
4. Lengkapi sel `[ISI KODE]`, jalankan definisinya, lalu jalankan sel pemeriksaan.
5. Bila kode diperbaiki, jalankan ulang definisi dan pemeriksaannya. Menyunting teks
   fungsi saja belum memperbarui fungsi dalam sesi Python.
6. Sebelum mengumpulkan, mulai ulang sesi dan jalankan seluruh sel.

## Mengapa fungsi dipisahkan?

Satu sel definisi memuat satu fungsi mandiri atau satu kelas. Sel pemanggilan dan
pengujian dipisahkan sehingga letak perubahan dan kesalahan lebih mudah ditemukan.
Metode dalam satu kelas dan fungsi bersarang tetap berada dalam satu sel karena
merupakan satu kesatuan Python. Kode diberi spasi di sekitar operator, setelah koma,
serta baris kosong untuk memisahkan bagian yang berbeda. Maksimum saat rilis ini:
28 baris kode per sel; kebanyakan sel lebih pendek.

## Refleksi akhir

Bagian ini sebelumnya berjudul “tiket keluar”. Tujuannya merangkum pemahaman,
menyebutkan kesulitan, dan menjelaskan alasan di balik kode berdasarkan percobaan.
Ini bukan perintah program dan bukan syarat teknis untuk menutup notebook.
Tulis jawaban singkat dengan kalimat sendiri pada bagian `[REFLEKSI]`.

## Status pemeriksaan

- BELUM DIISI: bagian latihan masih perlu dilengkapi.
- PERLU PERBAIKAN atau belum lulus: hasil belum sesuai kasus uji yang terlihat.
- GALAT: ada exception yang perlu ditelusuri dari pesannya.
- LULUS: seluruh kasus uji pada kelompok tersebut sudah sesuai.

Pengujian terlihat, sementara kode jawaban latihan berada dalam paket khusus
asisten. Contoh pembelajaran tetap disediakan. Refleksi dan alasan memilih cara
penyelesaian dibahas dengan asisten; status LULUS tidak membuktikan semua kemungkinan
input sudah benar. 

Seluruh notebook telah dijalankan ulang pada Jupyter lokal. Impor langsung melalui
akun Kaggle belum diuji.

Notebook terbaru: https://github.com/jamhuri-tech/buku-python-ml-kode/tree/main/praktikum
